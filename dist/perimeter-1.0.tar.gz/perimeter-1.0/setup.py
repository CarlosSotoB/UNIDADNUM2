from setuptools import setup

setup(
    name='perimeter',
    version='1.0',
    description='This madule calculate perimeter',
    author='Jose Carlos Soto Barco',
    author_email='carlilloz.soto@gmail.com',
    url='http://www.utng.edu.mx',
    py_modules=['perimeter']
)